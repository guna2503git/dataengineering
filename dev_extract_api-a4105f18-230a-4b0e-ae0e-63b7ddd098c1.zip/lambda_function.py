import json
import pandas as pd
import requests 
import consonants as constant
import boto3
from io import StringIO
import time
import datetime

sns = boto3.client("sns", region_name="eu-north-1")
ssm = boto3.client("ssm", region_name="eu-north-1")

api_key = ssm.get_parameter(Name=constant.key, WithDecryption=True)["Parameter"]["Value"]
url = ssm.get_parameter(Name=constant.urlapi, WithDecryption=True)["Parameter"]["Value"]
s3_resource = boto3.resource('s3')
s3_read = boto3.client('s3')
bucket  = 'gunada'

s3_prefix = "result/csvfiles"
def get_datetime():
    dt = datetime.datetime.now()
    return dt.strftime("%Y%m%d"), dt.strftime("%H:%M:%S")
datestr, timestr = get_datetime()
fname = f"data_api_tripler_{datestr}_{timestr}.csv"
file_prefix = "/".join([s3_prefix, fname])

def send_sns_success():
    success_sns_arn = ssm.get_parameter(Name=constant.SUCCESSNOTIFICATIONARN, WithDecryption=True)["Parameter"]["Value"]
    component_name = constant.COMPONENT_NAME
    env = ssm.get_parameter(Name=constant.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    success_msg = constant.SUCCESS_MSG
    sns_message = (f"{component_name} :  {success_msg}")
    print(sns_message, 'text')
    succ_response = sns.publish(TargetArn=success_sns_arn,Message=json.dumps({'default': json.dumps(sns_message)}),
        Subject= env + " : " + component_name,MessageStructure="json")
    return succ_response
    
def send_error_sns(e):
   
    error_sns_arn = ssm.get_parameter(Name=constant.ERRORNOTIFICATIONARN)["Parameter"]["Value"]
    env = ssm.get_parameter(Name=constant.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    #error_message=constant.ERROR_MSG
    error_message= str(e)
    component_name = constant.COMPONENT_NAME
    sns_message = (f"{component_name} : {error_message}")
    err_response = sns.publish(TargetArn=error_sns_arn,Message=json.dumps({'default': json.dumps(sns_message)}),    Subject=env + " : " + component_name,
        MessageStructure="json")
    return  err_response

max_retries = 3
def lambda_handler(event, context):
    retries = 0  # Initialize retries before the while loop
    while retries < max_retries:
        try:
            response = requests.get(url, params={'api_key': api_key})
            if response.status_code != 200:
                print("The URL is not hit. Sleeping for 30 seconds.")
                time.sleep(30)
            else:
                print("The URL is HIT")
                response.raise_for_status()
                json_data = response.json()
                print(json_data)
                movies = json_data.get("results", [])
                df = pd.DataFrame(movies)
                 # Example 1: Convert 'release_date' to datetime
                df['release_date'] = pd.to_datetime(df['release_date'])
                # Example 2: Extract year from 'release_date'
                df['release_year'] = df['release_date'].dt.year
                # Example 3: Create a new column 'is_highly_rated' based on 'vote_average'
                df['is_highly_rated'] = df['vote_average'] > 8.0
                df = df.sort_values(by='release_year', ascending=False)
                #print
                a = [1891,121,244786]
                df['status'] = df['id'].isin(a)
                df1 = df[['id','status','genre_ids']]
                df1 = df[['id','status','genre_ids']]
                max_elements = max(df['genre_ids'].apply(len))
                column_names = [f'genre_id_{i+1}' for i in range(max_elements)]
                df1[column_names] = df['genre_ids'].apply(lambda x: pd.Series(x + [None] * (max_elements - len(x))))
                csv_buffer1 = StringIO()
                df1.to_csv(csv_buffer1)
                # Writing the Files to CSV 
                s3_resource.Object(bucket, file_prefix).put(Body=csv_buffer1.getvalue())
                print('CSV files written')
                ####SUCCESS-SNS-NOTIFICATION ACTIVATED#####    
                send_sns_success()
                print('Email delivered')

                break  # Exit the loop when status code is 200
        except Exception as e:
            print(f"An error occurred: {e}")
            error_message=str(e)
            print(error_message)
            send_error_sns(error_message)
            print('error email delivered')
        retries += 1
        
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
